﻿
namespace GoogleVoice.NET
{
    public enum VoiceEventType
    {
        SMS, Call
    }
}